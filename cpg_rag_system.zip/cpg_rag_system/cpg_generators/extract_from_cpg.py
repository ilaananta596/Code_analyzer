#!/usr/bin/env python3
"""
Simple CPG Extractor - Extract nodes and edges from existing CPG

This script extracts data from an existing Joern CPG binary file.
Use this if you already have a cpg.bin file.

Usage:
    python extract_from_cpg.py --cpg cpg.bin --output ./data
    python extract_from_cpg.py --cpg cpg.bin --nodes-only
"""

import os
import sys
import subprocess
import argparse
import json
from pathlib import Path
from typing import Optional


class CPGExtractor:
    """Extract JSON from existing CPG binary."""
    
    def __init__(self, joern_path: Optional[str] = None):
        self.joern_path = joern_path or self._find_joern()
        self.joern_cli = os.path.join(self.joern_path, 'joern')
        
        if not os.path.exists(self.joern_cli):
            raise FileNotFoundError(f"Joern CLI not found at {self.joern_path}")
    
    def _find_joern(self) -> str:
        """Auto-detect Joern installation."""
        possible_paths = [
            '/opt/joern',
            '/usr/local/joern',
            os.path.expanduser('~/joern'),
        ]
        
        for path in possible_paths:
            if os.path.exists(os.path.join(path, 'joern')):
                return path
        
        raise FileNotFoundError("Joern not found. Use --joern-path")
    
    def extract_nodes(self, cpg_file: str, output_file: str):
        """Extract all METHOD nodes."""
        print("📤 Extracting nodes...")
        
        # Create Scala script for extraction
        script = f"""
import io.shiftleft.codepropertygraph.generated.nodes._
import scala.collection.JavaConverters._

val methods = cpg.method.l
val methodData = methods.map {{ m =>
  Map(
    "id" -> m.id.asInstanceOf[Object],
    "_label" -> "METHOD",
    "name" -> m.name,
    "signature" -> m.signature,
    "fullName" -> m.fullName,
    "filename" -> m.filename,
    "lineNumber" -> m.lineNumber.getOrElse(0).asInstanceOf[Object],
    "code" -> m.code,
    "isExternal" -> m.isExternal.asInstanceOf[Object]
  )
}}

// Convert to JSON manually
val jsonLines = methodData.map {{ m =>
  val fields = m.map {{ case (k, v) =>
    val valueStr = v match {{
      case s: String => "\\"" + s.replace("\\"", "\\\\\\"").replace("\\n", "\\\\n") + "\\""
      case n: Number => n.toString
      case b: Boolean => b.toString
      case _ => "\\"" + v.toString + "\\""
    }}
    s"\\"$$k\\": $$valueStr"
  }}.mkString(", ")
  s"{{$$fields}}"
}}

val json = "[\\n  " + jsonLines.mkString(",\\n  ") + "\\n]"

// Write to file
import java.nio.file.{{Files, Paths}}
Files.write(Paths.get("{output_file}"), json.getBytes("UTF-8"))

println(s"✅ Exported ${{methods.size}} nodes to {output_file}")
"""
        
        script_file = Path(output_file).parent / 'extract_nodes.sc'
        with open(script_file, 'w') as f:
            f.write(script)
        
        # Run Joern with script
        cmd = [
            self.joern_cli,
            '--script', str(script_file),
            '--cpg', cpg_file
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0 and os.path.exists(output_file):
            # Verify JSON
            try:
                with open(output_file) as f:
                    data = json.load(f)
                print(f"✅ Exported {len(data):,} nodes")
                script_file.unlink()
                return True
            except json.JSONDecodeError as e:
                print(f"⚠️  JSON decode error: {e}")
                return False
        else:
            print(f"❌ Export failed: {result.stderr}")
            return False
    
    def extract_edges(self, cpg_file: str, output_file: str):
        """Extract all CALL edges."""
        print("\n📤 Extracting edges...")
        
        script = f"""
// Get all method calls
val calls = cpg.call.l
val edges = calls.flatMap {{ call =>
  call.callee(NoResolve).l.map {{ callee =>
    Map(
      "src" -> call.id.asInstanceOf[Object],
      "dst" -> callee.id.asInstanceOf[Object],
      "label" -> "CALL"
    )
  }}
}}

// Convert to JSON
val jsonLines = edges.map {{ e =>
  val src = e("src")
  val dst = e("dst")
  val label = e("label")
  s"""{{\"src\": $$src, \"dst\": $$dst, \"label\": \"$$label\"}}"""
}}

val json = "[\\n  " + jsonLines.mkString(",\\n  ") + "\\n]"

// Write to file
import java.nio.file.{{Files, Paths}}
Files.write(Paths.get("{output_file}"), json.getBytes("UTF-8"))

println(s"✅ Exported ${{edges.size}} edges to {output_file}")
"""
        
        script_file = Path(output_file).parent / 'extract_edges.sc'
        with open(script_file, 'w') as f:
            f.write(script)
        
        # Run Joern with script
        cmd = [
            self.joern_cli,
            '--script', str(script_file),
            '--cpg', cpg_file
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0 and os.path.exists(output_file):
            try:
                with open(output_file) as f:
                    data = json.load(f)
                print(f"✅ Exported {len(data):,} edges")
                script_file.unlink()
                return True
            except json.JSONDecodeError as e:
                print(f"⚠️  JSON decode error: {e}")
                return False
        else:
            print(f"❌ Export failed: {result.stderr}")
            return False


def main():
    parser = argparse.ArgumentParser(
        description='Extract JSON from existing CPG binary'
    )
    
    parser.add_argument(
        '--cpg',
        required=True,
        help='Path to cpg.bin file'
    )
    
    parser.add_argument(
        '--output', '-o',
        default='./data',
        help='Output directory (default: ./data)'
    )
    
    parser.add_argument(
        '--nodes-only',
        action='store_true',
        help='Extract only nodes (skip edges)'
    )
    
    parser.add_argument(
        '--edges-only',
        action='store_true',
        help='Extract only edges (skip nodes)'
    )
    
    parser.add_argument(
        '--joern-path',
        help='Path to Joern installation'
    )
    
    args = parser.parse_args()
    
    if not os.path.exists(args.cpg):
        print(f"❌ CPG file not found: {args.cpg}")
        sys.exit(1)
    
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        extractor = CPGExtractor(joern_path=args.joern_path)
        
        success = True
        
        if not args.edges_only:
            nodes_file = output_dir / 'cpg_nodes.json'
            success = extractor.extract_nodes(args.cpg, str(nodes_file)) and success
        
        if not args.nodes_only:
            edges_file = output_dir / 'cpg_edges.json'
            success = extractor.extract_edges(args.cpg, str(edges_file)) and success
        
        if success:
            print("\n✅ Extraction complete!")
            print(f"\nOutput directory: {output_dir}")
            print("\nNext step:")
            print(f"  python main.py fault-detection --all")
        else:
            print("\n⚠️  Some extractions failed. Check output files.")
            sys.exit(1)
    
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
