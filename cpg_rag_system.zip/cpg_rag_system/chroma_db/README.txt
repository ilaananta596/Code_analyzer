Vector store data will be stored here
