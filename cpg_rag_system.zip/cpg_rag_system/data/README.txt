Place your cpg_nodes.json and cpg_edges.json here
